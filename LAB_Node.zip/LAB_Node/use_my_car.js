const car = require('./my_car');
car.drive();
car.break();
car.turn(15);